function GanjilGenap(){
    let angka = prompt("Masukkan Bilangan : ");
    
    if (angka % 2 === 0){
        alert( angka + " " + "ini Bilangan Genap");
    }
    else {
        alert (angka + " " + "ini Bilangan Ganjil");
    }
    }
    
    const tombol = document.getElementById("Masuk")
    tombol.addEventListener("click", GanjilGenap)